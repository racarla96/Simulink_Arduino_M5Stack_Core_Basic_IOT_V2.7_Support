#ifndef _RESOURCE_H_
#define _RESOURCE_H_

extern const unsigned char coordinator_jpeg_120x140[27537];
extern const unsigned char endDevice_jpeg_120x140[24609];
extern const unsigned char router_jpeg_120x140[26433];
extern const unsigned char EndDeviceTitle[17470];
extern const unsigned char coordinatorTitle[21823];
extern const unsigned char chatBubblesBottom[11546];
extern const unsigned char chatBubblesTop[10561];

#endif